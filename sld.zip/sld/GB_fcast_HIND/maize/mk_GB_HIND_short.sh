#!/bin/bash

store=ag_monitor_maize_GB:S_fcast_GB_HIND
template=GB_fcast_template.sld
declare -a months=(1 2 10 11 12)
dek=3

for yr in {2004..2024}; do
  for mo in "${months[@]}"; do
    date=$yr$mo$dek
    echo -n S_GB_HIND_$date.sld
    sed "s/_date_/F$date/" < $template | sed "s/_store_/$store/" > S_GB_HIND_$date.sld; 
  done
done

