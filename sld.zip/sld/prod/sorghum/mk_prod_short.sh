#!/bin/bash

store=ag_monitor_sorghum:S_prod
template=production_template.sld

for yr in {1982..2021}; do
    date=$yr
    echo -n "S_prod_$date.sld, "
    sed "s/_date_/O$date/" < $template | sed "s/_layer_/$store/" > S_prod_$date.sld;
done

