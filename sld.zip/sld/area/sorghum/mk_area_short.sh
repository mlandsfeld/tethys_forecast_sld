#!/bin/bash

store=ag_monitor_sorghum:S_area
template=area_template.sld

for yr in {1982..2022}; do
    date=$yr
    echo -n "area_S$date.sld"
    sed "s/_date_/O$date/" < $template | sed "s/_store_/$store/" > area_S$date.sld;
done

