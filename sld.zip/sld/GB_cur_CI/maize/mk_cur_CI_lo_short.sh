#!/bin/bash

store=ag_monitor_maize_GB:S_current_fcast_GB
template=GB_cur_CI_template.sld

for yr in {2021..2024}; do
  for mo in {1..12}; do
      dek=3
      date=$yr$mo$dek
      echo -n S_GB_cur_CI_lo_$date.sld ', '
      sed "s/_date_/LOF$date/" < $template | sed "s/_store_/$store/" > S_GB_cur_CI_lo_$date.sld; 
  done
done


