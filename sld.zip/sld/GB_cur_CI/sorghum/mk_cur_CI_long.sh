#!/bin/bash

store=ag_monitor_sorghum_GB:L_current_fcast_GB
template=GB_cur_CI_template.sld


for yr in {2021..2023}; do
  for mo in {1..12}; do
    dek=3
    #for dek in {1..3}; do
      date=$yr$mo$dek
      echo -n L_GB_cur_CI_$date.sld ', '
      sed "s/_date_/F$date/" < $template | sed "s/_store_/$store/" > L_GB_cur_CI_$date.sld; 
    #done
  done
done

