#!/bin/bash

store=ag_monitor_sorghum:S_fcast_ET_HIND
template=ET_fcast_template.sld

declare -a months=(1 2 9 10 11 12)
declare -a dekads=(1 3)

for yr in {2006..2023}; do
  for mo in 1 2 9 10 11 12; do
    for dek in 1 3; do
      date=$yr$mo$dek
      echo S_HIND_HIND_$date.sld
      sed "s/_date_/F$date/" < $template | sed "s/_store_/$store/" > S_ET_HIND_$date.sld; 
    done
  done
done

