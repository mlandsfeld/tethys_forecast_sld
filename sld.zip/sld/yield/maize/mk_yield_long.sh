#!/bin/bash

store=ag_monitor_maize:L_yield
template=yield_template.sld

for yr in {1982..2022}; do
    date=$yr
    echo -n "L_yield_$date.sld, "
    sed "s/_date_/O$date/" < $template | sed "s/_store_/$store/" > L_yield_$date.sld
done

