#!/bin/bash

store=ag_monitor_sorghum:S_fcast_error_ET
template=ET_error_template.sld
declare -a months=(1 2 9 10 11 12)

for yr in {2004..2022}; do
  for mo in ${months[@]}; do
    for dek in {1..3}; do
      date=$yr$mo$dek
      echo -n L_ET_err_$date.sld
      sed "s/_date_/E$date/" < $template | sed "s/_store_/$store/" > S_ET_err_$date.sld; 
    done
  done
done

