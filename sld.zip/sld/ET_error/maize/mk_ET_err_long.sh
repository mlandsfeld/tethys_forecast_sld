#!/bin/bash

store=ag_monitor_maize:L_fcast_error_ET
template=ET_error_template.sld

declare -a dekads=(1 3)

for yr in {2004..2022}; do
  for mo in {1..12}; do
    for dek in ${dekads[@]}; do
      date=$yr$mo$dek
      echo -n L_ET_err_$date.sld
      sed "s/_date_/E$date/" < $template | sed "s/_store_/$store/" > L_ET_err_$date.sld; 
    done
  done
done
