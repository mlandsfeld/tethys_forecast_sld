#!/bin/bash

store=ag_monitor_sorghum_GB:L_fcast_GB_percent
template=GB_fcast_pcnt_template.sld

#declare -a dekads=(1 3)

for yr in {2004..2023}; do
  for mo in {2..7}; do
    dek=3
    #for dek in ${dekads[@]}; do
      date=$yr$mo$dek
      echo -n L_GB_pcnt_$date.sld
      sed "s/_date_/F$date/" < $template | sed "s/_store_/$store/" > L_GB_pcnt_$date.sld; 
    #done
  done
done


