#!/bin/bash

store=ag_monitor_maize:L_fcast_ET
template=ET_fcast_template.sld

declare -a dekads=(1 3)

for yr in {2017..2023}; do
  for mo in {1..12}; do
    for dek in ${dekads[@]}; do
      date=$yr$mo$dek
      echo -n L_ET_fcast_$date.sld
      sed "s/_date_/F$date/" < $template | sed "s/_layer_/$store/" > L_ET_fcast_$date.sld; 
    done
  done
done

