#!/bin/bash

store=ag_monitor_sorghum:L_fcast_ET
template=ET_fcast_template.sld

for yr in {2004..2023}; do
  for mo in {1..12}; do
    for dek in {1..3}; do
      date=$yr$mo$dek
      echo -n L_ET_fcast_$date.sld
      sed "s/_date_/F$date/" < $template | sed "s/_store_/$store/" > L_ET_fcast_$date.sld; 
    done
  done
done

