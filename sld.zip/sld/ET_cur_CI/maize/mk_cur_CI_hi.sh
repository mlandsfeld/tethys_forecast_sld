#!/bin/bash

store=ag_monitor_maize:current_fcast_ET
template=ET_cur_CI_template.sld
dek=3

for yr in {2021..2024}; do
  for mo in {1..12}; do
    date=$yr$mo$dek
    echo -n ET_cur_CI_hi_$date.sld ', '
    sed "s/_date_/HIF$date/" < $template | sed "s/_store_/$store/" > ET_cur_CI_hi_$date.sld; 
  done
done


