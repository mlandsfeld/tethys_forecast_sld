#!/bin/bash

store=ag_monitor_sorghum:L_fcast_MAPE_ET
template=ET_MAPE_template.sld

  for mo in {1..12}; do
    for dek in {1..3}; do
      date=`echo $mo $dek | sed 's/ /_/g'`
      echo -n $date ' '
      sed "s/_date_/MP_$date/" < $template | sed "s/_store_/$store/" > L_ET_MAPE_$date.sld; 
    done
  done

