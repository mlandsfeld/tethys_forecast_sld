#!/bin/bash

store=ag_monitor_sorghum:S_fcast_ET_percent
template=ET_fcast_pcnt_template.sld

declare -a dekads=(1 3)
declare -a months=(1 2 9 10 11 12)

for yr in {2004..2023}; do
  for mo in {1..12}; do
    for dek in ${dekads[@]}; do
      date=$yr$mo$dek
      echo -n S_ET_pcnt_$date.sld ', '
      sed "s/_date_/F$date/" < $template | sed "s/_store_/$store/" > S_ET_pcnt_$date.sld; 
    done
  done
done


