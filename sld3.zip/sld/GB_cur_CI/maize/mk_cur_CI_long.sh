#!/bin/bash

store=ag_monitor_maize_GB:L_current_fcast_GB
template=GB_cur_CI_template.sld


for yr in {2021..2024}; do
  for mo in {1..12}; do
      dek=3
      date=$yr$mo$dek
      echo -n L_GB_cur_CI_$date.sld ', '
  done
done

