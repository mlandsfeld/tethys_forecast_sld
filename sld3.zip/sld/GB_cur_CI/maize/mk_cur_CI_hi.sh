#!/bin/bash

store=ag_monitor_maize_GB:current_fcast_GB
template=GB_cur_CI_template.sld

declare -a months=(1 2 9 10 11 12)

for yr in {2021..2024}; do
  for mo in {1..12}; do
      dek=3
      date=$yr$mo$dek
      echo -n GB_cur_CI_hi_$date.sld ', '
      sed "s/_date_/HIF$date/" < $template | sed "s/_store_/$store/" > GB_cur_CI_hi_$date.sld; 
  done
done


