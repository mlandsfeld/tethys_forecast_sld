#!/bin/bash

store=ag_monitor_sorghum:L_prod
template=production_template.sld

for yr in {1982..2021}; do
    date=$yr
    echo -n "prod_$date.sld"
    sed "s/_date_/O$date/" < $template | sed "s/_layer_/$store/" > L_prod_$date.sld;
done

