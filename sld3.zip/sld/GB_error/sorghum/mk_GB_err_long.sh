#!/bin/bash

store=ag_monitor_sorghum_GB:L_fcast_error_GB
template=GB_error_template.sld

dek=3

for yr in {2004..2023}; do
  for mo in {1..12}; do
    date=$yr$mo$dek
    echo -n L_GB_err_$date.sld
    sed "s/_date_/E$date/" < $template | sed "s/_store_/$store/" > L_GB_err_$date.sld; 
  done
done

