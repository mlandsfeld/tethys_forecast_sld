#!/bin/bash

store=ag_monitor_maize_GB:L_fcast_MAPE_GB
template=GB_MAPE_template.sld
dek=3

for mo in {1..12}; do
    date=`echo "$mo $dek" | sed 's/ /_/g'`
    feature=`echo "MP $mo $dek" | sed 's/ /_/g'`
    echo -n "L_GB_MAPE_$date.sld"
    sed "s/_date_/$feature/" < $template | sed "s/_store_/$store/" > L_GB_MAPE_$date.sld;
done

