#!/bin/bash

store=ag_monitor_sorghum_GB:S_fcast_MAPE_GB
template=GB_MAPE_template.sld
declare -a months=(1 2 10 11 12)
dek=3

for mo in "${months[@]}"; do

    date=`echo "$mo $dek" | sed 's/ /_/g'`
    feature=`echo "MP $mo $dek" | sed 's/ /_/g'`
    echo -n "S_GB_MAPE_$date.sld"
    sed "s/_date_/$feature/" < $template | sed "s/_store_/$store/" > S_GB_MAPE_$date.sld;
done

