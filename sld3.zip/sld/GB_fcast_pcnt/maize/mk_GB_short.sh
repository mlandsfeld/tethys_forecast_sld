#!/bin/bash

store=ag_monitor_maize_GB:S_fcast_GB_percent
template=GB_fcast_pcnt_template.sld

declare -a months=(1 2 9 10 11 12)

for yr in {2004..2024}; do
  for mo in {1..12}; do
      dek=3
      date=$yr$mo$dek
      echo -n S_GB_pcnt_$date.sld
      sed "s/_date_/F$date/" < $template | sed "s/_store_/$store/" > S_GB_pcnt_$date.sld; 
  done
done

