#!/bin/bash

store=ag_monitor_maize:S_yield
template=yield_template.sld

for yr in {1982..2022}; do
    date=$yr
    echo -n "S_yield_$date.sld, "
    sed "s/_date_/O$date/" < $template | sed "s/_store_/$store/" > S_yield_$date.sld
done

